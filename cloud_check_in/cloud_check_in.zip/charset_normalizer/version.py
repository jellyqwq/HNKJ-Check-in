"""
Expose version
"""

__version__ = "2.0.4"
VERSION = __version__.split('.')
